'use strict';

// Global setting keys - like environment variables
const SETTINGS = {
    API_BASE_URL: 'https://dev.virtualearth.net/REST/v1',
    API_KEY : 'AtHE9bgbozoYqBc4UaubjFAw9L16qnnD4-B4UgDGoGu3K2HXBUq_YffNmxAXuaQ9'
};