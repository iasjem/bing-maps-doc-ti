// Imagery Services

var API_BASE_URL = SETTINGS.API_BASE_URL + "/Imagery";

var Imagery = {
    getRoadMap: (pp, mapSize, mapLayer, zoomLevel, metadata, declutter) => {
        if (!pp) {
            return null;
        }

        var pushpin = pp ? pp.split("|").map(pin => "&pp=" + pin).join("").replace(/\s/g, "") : "";
        var size = mapSize ? "&mapSize=" + mapSize : "";
        var layer = mapLayer ? "&mapLayer=" + mapLayer : "";
        var mapMetadata = "&mapMetadata=1";
        var dcl = declutter ? "&dcl=" + declutter : "";
        var zoom = zoomLevel ? zoomLevel : "18";
        var key = "?key=" + SETTINGS.API_KEY;
        var GET_ROADMAP_API_ENDPOINT = API_BASE_URL + "/Map/Road/" + pp.split("|")[0].replace(/\s/g, "") + "/" + zoom + key + pushpin + size + layer + dcl;

        var request = new Request(
            GET_ROADMAP_API_ENDPOINT + mapMetadata,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return {
            responseContent: responseContent,
            image_url: metadata && metadata === "1" ? null : GET_ROADMAP_API_ENDPOINT
            
        };
    },
    getRouteMap: (mapSize, mapLayer, metadata, declutter, waypoints) => {
        if (!waypoints) {
            return null;
        }

        var wpn = waypoints ? waypoints.split("|").map((wp, i) => "&wp." + i + "=" + encodeURIComponent(wp)).join("") : "";

        var size = mapSize ? "&mapSize=" + mapSize : "";
        var layer = mapLayer ? "&mapLayer=" + mapLayer : "";
        var mapMetadata = "&mapMetadata=1";
        var dcl = declutter ? "&dcl=" + declutter : "";
        var key = "?key=" + SETTINGS.API_KEY;
        var GET_ROUTESMAP_API_ENDPOINT = API_BASE_URL + "/Map/Road/Routes" + key + wpn + size + layer + dcl;

        var request = new Request(
            GET_ROUTESMAP_API_ENDPOINT + mapMetadata,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return {
            responseContent: responseContent,
            image_url: metadata && metadata === "1" ? null : GET_ROUTESMAP_API_ENDPOINT
            
        };
    }
};