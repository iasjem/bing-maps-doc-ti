// Traffic Services

var API_BASE_URL = SETTINGS.API_BASE_URL + "/Traffic/Incidents";

var Traffic = {
    getTrafficIncidents: (locationMapArea, includeLocationCodes, severity, type) => {
        if (!locationMapArea && !includeLocationCodes) {
            return null;
        }

        var mapArea = locationMapArea ? locationMapArea : "";
        var locationCodes = includeLocationCodes ? includeLocationCodes : "";

        var s = severity ? "&s=" + severity : "";
        var t = type ? "&t=" + type : "";

        var key = "?key=" + SETTINGS.API_KEY;
        var GET_TRAFFIC_INCIDENTS_API_ENDPOINT = API_BASE_URL + "/" + mapArea + "/" + locationCodes + key + s + t;

        var request = new Request(
            GET_TRAFFIC_INCIDENTS_API_ENDPOINT,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return responseContent;
    }
};