// Traffic API

// Query Parameters
var mapArea = context.getVariable('mapArea');
var locationCodes = context.getVariable('locationCodes');
var severity = context.getVariable('severity');
var type = context.getVariable('type');

// Functions
function getTraffic () {
    var getTrafficIncidents = Traffic.getTrafficIncidents(mapArea, locationCodes, severity, type);
    return getTrafficIncidents && getTrafficIncidents.content ? parseToJSON(getTrafficIncidents.content) : null;
}

// Response Controller
(function () {
    var results = getTraffic();

    if (results && results.statusCode === 200) {
        var data = results.resourceSets[0];
        var response = stringifyJSON({
            status: results.statusCode || 200,
            title: results.statusDescription || "OK",
            details: "Search Successful!",
            message: data.estimatedTotal > 0 ? data.estimatedTotal + " results found" : "No results found",
            count: data.estimatedTotal,
            data: data.resources
        });
    
        context.setVariable('resStatus', results.statusCode || 200);
        context.setVariable('resObj', response);
    } else {
        var errResponse = {
            "error": {
                        "status": results ? results.content.statusCode : 400,
                        "title": results ? results.content.statusDescription : "Bad Request",
                        "message": results ? results.content.errorDetails : "Something went wrong with your request. Please try again."
            }
        };

        context.setVariable('resStatus', results ? results.content.statusCode : 400);
        context.setVariable('resObj', stringifyJSON(errResponse));
    }
})();
