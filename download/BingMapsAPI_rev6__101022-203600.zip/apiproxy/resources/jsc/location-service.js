// Location Services

var API_BASE_URL = SETTINGS.API_BASE_URL + "/Locations";
var LOCATION_RECOGNITION_API_BASE_URL = SETTINGS.API_BASE_URL + "/locationrecog";

var Location = {
    findByAddress: (locationCountryRegion, adminDistrict, locality, postalCode, addressLine, strictMatch, includeNeighborhood, includeValue, maxResults) => {
        if (!locationCountryRegion) {
            return null;
        }
        print(adminDistrict)
        var countryRegion = locationCountryRegion ? "/" + encodeURIComponent(locationCountryRegion) : "";
        var district = adminDistrict ? "/" + encodeURIComponent(adminDistrict) : "";
        var address = addressLine ? "/" + encodeURIComponent(addressLine) : "";
        var local = locality ? "/" + encodeURIComponent(locality) : "";
        var postal = postalCode ? "/" + encodeURIComponent(postalCode) : "";
        var sm = strictMatch ? "&strictMatch=" + strictMatch : "";
        var neighborhood = includeNeighborhood ? "&includeNeighborhood=" + encodeURIComponent(includeNeighborhood) : "";
        var value = includeValue ? "&include=" + encodeURIComponent(includeValue) : "";
        var max = maxResults ? "&maxResults=" + maxResults : "";
        var key = "?key=" + SETTINGS.API_KEY;
        var FIND_LOCATION_API_ENDPOINT = API_BASE_URL + countryRegion + district + postal + local + address + key + sm + neighborhood + value + max;
        print('FIND_LOCATION_API_ENDPOINT', FIND_LOCATION_API_ENDPOINT)
        var request = new Request(
            FIND_LOCATION_API_ENDPOINT,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return responseContent;
    },
    findByQuery: (locationQuery, includeNeighborhood, includeValue, maxResults) => {
        if (!locationQuery) {
            return null;
        }

        var query = locationQuery ? "&query=" + encodeURIComponent(locationQuery) : "";
        var neighborhood = includeNeighborhood ? "&includeNeighborhood=" + encodeURIComponent(includeNeighborhood) : "";
        var value = includeValue ? "&include=" + encodeURIComponent(includeValue) : "";
        var max = maxResults ? "&maxResults=" + maxResults : "";
        var key = "?key=" + SETTINGS.API_KEY;
        var FIND_LOCATION_API_ENDPOINT = API_BASE_URL + key + query + neighborhood + value + max ;

        var request = new Request(
            FIND_LOCATION_API_ENDPOINT,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return responseContent;
    },
    findByPoint: (locationPoint, includeNeighborhood, includeValue, maxResults, verbosePlaceNames, includeEntityTypes) => {
        if (!locationPoint) {
            return null;
        }

        var point = locationPoint ? locationPoint : "";

        var neighborhood = includeNeighborhood ? "&includeNeighborhood=" + encodeURIComponent(includeNeighborhood) : "";
        var value = includeValue ? "&include=" + encodeURIComponent(includeValue) : "";
        var max = maxResults ? "&maxResults=" + maxResults : "";
        var verbose = verbosePlaceNames ? "&verboseplacenames=" + verbosePlaceNames : "";
        var entityTypes = includeEntityTypes ? "&includeEntityTypes=" + includeEntityTypes : "";
        var key = "?key=" + SETTINGS.API_KEY;
        var FIND_LOCATION_API_ENDPOINT = API_BASE_URL + "/" + point + key + neighborhood + value + max + verbose + entityTypes;

        var request = new Request(
            FIND_LOCATION_API_ENDPOINT,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return responseContent;
    },
    locationRecognition: (locationPoint, radius, top, distanceUnit, verbosePlaceNames, includeEntityTypes) => {
        if (!locationPoint) {
            return null;
        }

        var point = locationPoint ? locationPoint : "";

        var r = radius ? "&r=" + radius : "";
        var t = top ? "&top=" + top : "";
        var distance = distanceUnit ? "&distanceUnit=" + distanceUnit : "";
        var verbose = verbosePlaceNames ? "&verboseplacenames=" + verbosePlaceNames : "";
        var entityTypes = includeEntityTypes ? "&includeEntityTypes=" + includeEntityTypes : "";
        var key = "?key=" + SETTINGS.API_KEY;
        var LOCATION_RECOGNITION_API_ENDPOINT = LOCATION_RECOGNITION_API_BASE_URL + "/" + point + key + r + t + distance + verbose + entityTypes;

        var request = new Request(
            LOCATION_RECOGNITION_API_ENDPOINT,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return responseContent;
    }
};