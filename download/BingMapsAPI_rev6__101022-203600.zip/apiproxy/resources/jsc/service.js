 'use strict';

var SERVICES = {
    fetch: (request) => {
        var response = httpClient.send(request);
        response.waitForComplete();
        
        if (response.isSuccess())  return response.getResponse();
        else if (response.isError()) throw new Error(response.getError());
    }
};