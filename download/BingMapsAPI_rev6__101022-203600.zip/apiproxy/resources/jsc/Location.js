// Locations API

// Query Parameters
var search = context.getVariable('search');
var q = context.getVariable('q');
var p = context.getVariable('p');
var inclnb = context.getVariable('inclnb');
var incl = context.getVariable('incl');
var limit = context.getVariable('limit');
var vbpn = context.getVariable('vbpn');
var inet = context.getVariable('inet');
var country = context.getVariable('country');
var district = context.getVariable('district');
var address = context.getVariable('address');
var local = context.getVariable('local');
var postal = context.getVariable('postal');
var sm = context.getVariable('sm');
var r = context.getVariable('r');
var t = context.getVariable('t');
var du = context.getVariable('du');

// Functions
function findLocation (search) {
    switch(search) {
        case "query":
            var findLocationByQuery = Location.findByQuery(q, inclnb, incl, limit);
            return findLocationByQuery && findLocationByQuery.content ? parseToJSON(findLocationByQuery.content) : null;
        case "point":
            var findLocationByPoint = Location.findByPoint(p, inclnb, incl, limit, vbpn, inet);
            return findLocationByPoint && findLocationByPoint.content ? parseToJSON(findLocationByPoint.content) : null;
        case "address":
            var findLocationByAddress = Location.findByAddress(country, district, local, postal, address, sm, inclnb, incl, limit);
            return findLocationByAddress && findLocationByAddress.content ? parseToJSON(findLocationByAddress.content) : null;
        case "recognition":
            var locationRecognition = Location.locationRecognition(p, r, t, du, vbpn, inet);
            return locationRecognition && locationRecognition.content ? parseToJSON(locationRecognition.content) : null;
        default:
            return null;
    }
}

// Response Controller
(function () {
    var results = findLocation(search);

    if (results && results.statusCode === 200) {
        var data = results.resourceSets[0];
        var response = stringifyJSON({
            status: results.statusCode || 200,
            title: results.statusDescription || "OK",
            details: "Search Successful!",
            message: data.estimatedTotal > 0 ? data.estimatedTotal + " results found" : "No results found",
            count: data.estimatedTotal ? data.estimatedTotal : 0,
            data: search === "recognition" ? data.resources : data.resources.map(function (item, i) {
                return {
                    "_id": i + 1,
                    "bbox": item.bbox,
                    "name": item.name,
                    "point": item.point,
                    "entityType": item.entityType,
                    "address": item.address,
                    "geocodePoints": item.geocodePoints
                }
            })
        });

        context.setVariable('resStatus', results.statusCode || 200);
        context.setVariable('resObj', response);
    } else {
        var errResponse = {
            "error": {
                        "status": results ? results.content.statusCode : 400,
                        "title": results ? results.content.statusDescription : "Bad Request",
                        "message": results ? results.content.errorDetails : "Something went wrong with your request. Please try again."
            }
        };

        context.setVariable('resStatus', results ? results.content.statusCode : 400);
        context.setVariable('resObj', stringifyJSON(errResponse));
    }
})();
