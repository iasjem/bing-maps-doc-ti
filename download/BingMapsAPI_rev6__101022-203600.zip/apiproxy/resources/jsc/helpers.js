// Helper functions

function stringifyJSON(obj) {
    return JSON.stringify(obj, null, 2);
}

function parseToJSON(obj) {
    return JSON.parse(obj);
}