// Routes Services

var API_BASE_URL = SETTINGS.API_BASE_URL + "/Routes";

var Routes = {
    calculateByDistanceMatrix: (travelMode, origins, destinations, du, tu) => {
        if (!origins || !destinations) {
            return null;
        }

        var orig = "&origins=" + (origins ?  origins.split("|").map((origin, i) => origin).join(";") : "");
        var dest = "&destinations=" + (destinations ?  destinations.split("|").map((destination, i) => destination).join(";") : "");
        var mode = travelMode ? "&travelMode=" + travelMode : "&travelMode=driving";
        var distanceUnit = du ? "&distanceUnit=" + du : "";
        var timeUnit = tu ? "&timeUnit=" + tu : "";
        var key = "?key=" + SETTINGS.API_KEY;
        var CALCULATE_DISTANCE_MATRIX_API_ENDPOINT = API_BASE_URL + "/DistanceMatrix" + key + orig + dest + mode + distanceUnit + timeUnit;

        var request = new Request(
            CALCULATE_DISTANCE_MATRIX_API_ENDPOINT,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return responseContent;
    },
    calculateByRoutes: (travelMode, waypoints, optimize, ig, avoid, du) => {
        if (!waypoints) {
            return null;
        }

        var wpn = waypoints ? waypoints.split("|").map((wp, i) => "&wp." + i + "=" + encodeURIComponent(wp)).join("") : "";
        var mode = travelMode ? travelMode : "driving";
        var optmz = optimize ? "&optmz=" + optimize : "";
        var itineraryGroups = ig ? "&ig=" + ig : "";
        var avd = avoid ? "&avoid=" + avoid : "";
        var distanceUnit = du ? "&distanceUnit=" + du : "";
        var key = "?key=" + SETTINGS.API_KEY;
        var CALCULATE_ROUTES_API_ENDPOINT = API_BASE_URL + "/" + mode + key + wpn + optmz + itineraryGroups + avd + distanceUnit;

        var request = new Request(
            CALCULATE_ROUTES_API_ENDPOINT,
            "GET",
            {"Content-Type": "application/json"},
            null
        );

        var responseContent = SERVICES.fetch(request);

        return responseContent;
    }
};