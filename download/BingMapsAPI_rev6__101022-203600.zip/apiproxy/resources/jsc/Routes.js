// Routes API

// Query Parameters
var key = context.getVariable('key');
var travelMode = context.getVariable('travelMode');
var waypoints = context.getVariable('waypoints');
var optmz = context.getVariable('optmz');
var orig = context.getVariable('orig');
var dest = context.getVariable('dest');
var du = context.getVariable('du');
var tu = context.getVariable('tu');
var ig = context.getVariable('ig');
var avoid = context.getVariable('avoid');

// Functions
function findRoutes (key) {
    switch(key) {
        case "routes":
            var calculateByRoutes = Routes.calculateByRoutes(travelMode, waypoints, optmz, ig, avoid, du);
            return calculateByRoutes && calculateByRoutes.content ? parseToJSON(calculateByRoutes.content) : null;
        case "distance_matrix":
            var calculateByDistanceMatrix = Routes.calculateByDistanceMatrix(travelMode, orig, dest, du, tu);
            return calculateByDistanceMatrix && calculateByDistanceMatrix.content ? parseToJSON(calculateByDistanceMatrix.content) : null;
        default:
            return null;
    }
}

// Response Controller
(function () {
    var results = findRoutes(key);

    if (results && results.statusCode === 200) {
        var data = results.resourceSets[0];

        var response = stringifyJSON({
            status: results.statusCode || 200,
            title: results.statusDescription || "OK",
            details: "Search Successful!",
            message: data.estimatedTotal > 0 ? data.estimatedTotal + " results found" : "No results found",
            count: data.estimatedTotal,
            data: key === "routes" ? data.resources.map((route, i) => {
                return {
                    _id: i + 1,
                    bbox: route.bbox,
                    travelMode: route.travelMode,
                    trafficCongestion: route.trafficCongestion,
                    trafficDataUsed: route.trafficDataUsed,
                    distance: route.travelDistance + " " + route.distanceUnit + "s",
                    duration: route.travelDuration + " " + route.durationUnit + "s",
                    trafficDuration: route.travelDurationTraffic + " " + route.durationUnit + "s",
                    routes: route.routeLegs
                }
            }) : data.resources
        });
    
        context.setVariable('resStatus', results.statusCode || 200);
        context.setVariable('resObj', response);
    } else {
        var errResponse = {
            "error": {
                        "status": results ? results.content.statusCode : 400,
                        "title": results ? results.content.statusDescription : "Bad Request",
                        "message": results ? results.content.errorDetails : "Something went wrong with your request. Please try again."
            }
        };

        context.setVariable('resStatus', results ? results.content.statusCode : 400);
        context.setVariable('resObj', stringifyJSON(errResponse));
    }
})();
