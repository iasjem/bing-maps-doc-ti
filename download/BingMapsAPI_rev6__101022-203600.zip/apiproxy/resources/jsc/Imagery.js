// Imagery API

// Query Parameters
var key = context.getVariable('key');
var pp = context.getVariable('pp');
var mapSize = context.getVariable('mapSize');
var mapLayer = context.getVariable('mapLayer');
var zoomLevel = context.getVariable('zoomLevel');
var metadata = context.getVariable('metadata');
var declutter = context.getVariable('declutter');
var waypoints = context.getVariable('waypoints');

// Functions
function getImagery (key) {
    switch(key) {
        case "road_map":
            var getRoadMap = Imagery.getRoadMap(pp, mapSize, mapLayer, zoomLevel, metadata, declutter);

            return getRoadMap && getRoadMap.responseContent.content ? {
                        content: parseToJSON(getRoadMap.responseContent.content),
                        image_url: parseToJSON(getRoadMap.responseContent.content).statusCode === 200 ? getRoadMap.image_url : null  } : null;
        case "route_map":
            var getRouteMap = Imagery.getRouteMap(mapSize, mapLayer, metadata, declutter, waypoints);

            return getRouteMap && getRouteMap.responseContent.content ? {
                    content: parseToJSON(getRouteMap.responseContent.content),
                    image_url: parseToJSON(getRouteMap.responseContent.content).statusCode === 200 ? getRouteMap.image_url : null } : null;
        default:
            return null;
    }
}

// RESPONSE CONTROLLER
(function () {
    var results = getImagery(key);

    if (results && results.content.statusCode === 200) {
        var data = results.content.resourceSets[0];
        var response = stringifyJSON({
            status: results.content.statusCode || 200,
            title: results.content.statusDescription || "OK",
            details: "Map Generated Successfulyl",
            data: {
                map_image_url: results.image_url,
                metadata: metadata ? results.content.resourceSets[0] : null
            }
        });

        context.setVariable('resStatus', results.content.statusCode || 200);
        context.setVariable('resObj', response);
    } else {
        var errResponse = {
            "error": {
                        "status": results ? results.content.statusCode : 400,
                        "title": results ? results.content.statusDescription : "Bad Request",
                        "message": results ? results.content.errorDetails : "Something went wrong with your request. Please try again."
            }
        };

        context.setVariable('resStatus', results ? results.content.statusCode : 400);
        context.setVariable('resObj', stringifyJSON(errResponse));
    }
})();
