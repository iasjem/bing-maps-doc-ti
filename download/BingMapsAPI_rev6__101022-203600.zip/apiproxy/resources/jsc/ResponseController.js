'use strict';

var response = context.getVariable('resObj');
var status = context.getVariable('resStatus');

context.setVariable('response.status.code', status);
context.setVariable('response.content', response);