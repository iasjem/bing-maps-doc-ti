'use strict'

var html = '';

html += "<!DOCTYPE html>";
html += "<html>";
html += "<head>";
html += "    <title>Bing Maps Sample</title>";
html += "    <meta charset='utf-8' />";
html += "<style>";
html += "body {";
html += "    margin: 0;";
html += "    padding: 0;";
html += "}";
html += "iframe {";
html += "    height: calc(100vh - 4px);";
html += "    border: none;";
html += "    width: 100%;";
html += "}";
html += "</style>";
html += "</head>";
html += "<body>";
html += "    <iframe src='https://iasjem.github.io/bing-maps-doc-ti' />";
html += "</body>";
html += "</html>";

context.setVariable('resStatus', 200);
context.setVariable('resObj', html);